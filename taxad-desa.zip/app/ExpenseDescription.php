<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpenseDescription extends Model
{
    //
}

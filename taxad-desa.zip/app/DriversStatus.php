<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DriversStatus extends Model
{
    //
}

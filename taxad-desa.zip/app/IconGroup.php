<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IconGroup extends Model
{
    //
}

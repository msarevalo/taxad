function notificaciones(){	

	//var usuario = $(this).val();
	//ajax
	/*$.get('/api/notificaciones/'+usuario+'/alertas', function(data) {
		var html_select= data.length;
		//console.log(html_select);
		$('#alertas').html(html_select);
	});*/
	alert("prueba");
}
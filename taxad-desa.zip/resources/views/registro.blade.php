@extends('autenticacion')

<title>Taxad | Registro</title>

@section('formulario')
    <h1>Registro</h1>
@endsection
@extends('autenticacion')

<title>Taxad | Login</title>

@section('formulario')
    <h1>Login</h1>
@endsection
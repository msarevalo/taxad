<title>Taxad | Conductores</title>

<?php $__env->startSection('formulario'); ?>
    <div class="container">
        <form action="<?php echo e(route('marca.editar', $marca->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <input type="text" name="marca" value="<?php echo e($marca->marca); ?>" class="form-control mb-2" required>
            <select class="form-control mb-2" name="estado" required>
                <?php if($marca->estado==1): ?>
                    <option selected value="1">Activo</option>
                    <option value="0">Inactivo</option>
                <?php else: ?>
                    <option value="1">Activo</option>
                    <option selected value="0">Inactivo</option>
                <?php endif; ?>
            </select>
            <button class="btn btn-primary btn-block" type="submit">Agregar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/marcas/edita.blade.php ENDPATH**/ ?>
<title>Taxad | Separadores</title>

<?php $__env->startSection('formulario'); ?>
<div class="container">
        <a href="<?php echo e(route('separador.crea')); ?>" class="btn btn-primary">Crear</a>
    </div>
    <h1>Listado Separadores:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Menu Posterior</th>
            <th scope="col">Estado</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $separadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $separador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<tr>
        		<th scope="row"><?php echo e($separador->id); ?></th>
        		<td>
        			<?php echo e($separador->nombre); ?>

        		</td>
        		<td>
        			<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $men): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				<?php if($separador->menu_posterior==$men->id): ?>
        					<?php echo e($men->nombre); ?>

        				<?php endif; ?>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</td>
        		<td>
        			<?php if($separador->estado==1): ?>
        				Activo
        			<?php else: ?>
        				Inactivo
        			<?php endif; ?>
        		</td>
        		<td>
        			<a href="<?php echo e(route('separador.edita', $separador->id)); ?>" style="text-decoration: none">
                	<button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                 </a>
        		</td>
        	</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/separadores.blade.php ENDPATH**/ ?>
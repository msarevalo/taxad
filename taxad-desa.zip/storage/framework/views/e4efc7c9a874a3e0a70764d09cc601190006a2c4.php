<title>Taxad | Taxis</title>

<?php $__env->startSection('formulario'); ?>
    <form action="<?php echo e(route('taxi.soatcargar', $taxi->id)); ?>" method="post" enctype="multipart/form-data">
    	<?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="name" class="col-md-1 col-form-label"><?php echo e(__('SOAT')); ?></label>

            <div class="col-6">
            	<input id="soat" type="file" class="" name="soat" value="<?php echo e(old('soat')); ?>" required autocomplete="soat" autofocus accept="application/pdf">
            </div>
        </div>
        <button class="btn btn-primary" type="submit">Agregar SOAT</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/soat.blade.php ENDPATH**/ ?>
<title>Taxad | Separador</title>

<?php $__env->startSection('formulario'); ?>
<div class="container">
        <form action="<?php echo e(route('separador.editar', $separador->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                <div class="col-md-6">
                    <input id="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" required autocomplete="nombre" autofocus value="<?php echo e($separador->nombre); ?>">

                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="menu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Menu Posterior')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="menu" id="menu" required style="text-transform: capitalize">
                        <option disabled selected>Seleccione una opción</option>
                        <?php $__currentLoopData = $padres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($padre->nombre!="Cerrar Sesión"): ?>
                                <?php if($separador->menu_posterior==$padre->id): ?>
                                    <option style="text-transform: capitalize" value="<?php echo e($padre->id); ?>" selected><?php echo e($padre->nombre); ?></option>
                                <?php else: ?>
                                    <option style="text-transform: capitalize" value="<?php echo e($padre->id); ?>" ><?php echo e($padre->nombre); ?></option>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="fa fa-fw mr-3"><i id="icono" aria-hidden="true" style="display: inline-block;"></i></span>
                </div>
            </div>

            <div class="form-group row">
                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="estado" id="estado" required style="text-transform: capitalize">
                        <option disabled>Seleccione una opción</option>
                        <?php if($separador->estado==0): ?>
                        	<option style="text-transform: capitalize" value="1">Activo</option>
                        	<option style="text-transform: capitalize" value="0" selected>Inactivo</option>
                        <?php else: ?>
                        	<option style="text-transform: capitalize" value="1" selected>Activo</option>
                        	<option style="text-transform: capitalize" value="0">Inactivo</option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Editar')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/administrativo/separador/edit.blade.php ENDPATH**/ ?>
<title>Taxad | Conductores</title>

<?php $__env->startSection('formulario'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('mensaje-delete')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('mensaje-delete')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('documento')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('documento')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <a href="<?php echo e(route('conductor.crea')); ?>" class="btn btn-primary">Crear</a>
    </div>
    <h1>Listado Conductores:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Documento</th>
            <th scope="col">Usuario</th>
            <th scope="col">Nombre Completo</th>
            <th scope="col">Perfil</th>
            <th scope="col">Estado</th>
            <th scope="col">Fecha Creacion</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($conductor->id); ?></th>
            <td>
                <a href="<?php echo e(route('conductor.detalle', $conductor)); ?>">
                    <?php echo e($conductor->document); ?>

                </a>
            </td>
            <td>
                <a href="<?php echo e(route('conductor.detalle', $conductor)); ?>">
                    <?php echo e($conductor->username); ?>

                </a>
            </td>
            <td>
                <a href="<?php echo e(route('conductor.detalle', $conductor)); ?>">
                    <?php echo e($conductor->name . " " .  $conductor->lastname . " " . $conductor->lastname2); ?>

                </a>
            </td>
            <td>
                <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($conductor->perfil==$perfil->id): ?>
                        <?php echo e($perfil->nombrePerfil); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($conductor->estado==$estado->id): ?>
                    <td><?php echo e($estado->estado); ?></td>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($conductor->created_at); ?></td>
            <td>
                <?php if($conductor->estado==2): ?>
                    <a href="<?php echo e(route('conductor.permitir', $conductor)); ?>" style="text-decoration: none">
                        <button style="width: 30px; height: 30px" class="btn btn-sm"><img src="../../img/aprobar.png" style="width: 130%; text-decoration: none"></button>
                    </a>
                    <form action="<?php echo e(route('conductor.negar', $conductor)); ?>" method="post" class="d-inline">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-user-times" aria-hidden="true" title="Negar"></i></button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('conductor.edita', $conductor)); ?>" style="text-decoration: none">
                        <button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                    </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($conductores->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/conductores.blade.php ENDPATH**/ ?>
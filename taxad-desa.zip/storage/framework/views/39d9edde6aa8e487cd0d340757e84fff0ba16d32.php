<title>Taxad | Menu</title>

<?php $__env->startSection('formulario'); ?>
<div class="container">
        <form action="<?php echo e(route('menu.editar', $menu->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                <div class="col-md-6">
                    <input id="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" required autocomplete="nombre" autofocus value="<?php echo e($menu->nombre); ?>">

                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="ruta" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ruta')); ?></label>

                <div class="col-md-6">
                    <input id="ruta" type="text" class="form-control <?php $__errorArgs = ['ruta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ruta" required autocomplete="ruta" autofocus value="<?php echo e($menu->ruta); ?>" disabled>

                    <?php $__errorArgs = ['ruta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="submenu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Submenu')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="submenu" id="submenu" required style="text-transform: capitalize">
                        <option disabled>Seleccione una opción</option>
                        <?php if($menu->submenu==0): ?>
                        	<option style="text-transform: capitalize" value="1">Si</option>
                        	<option style="text-transform: capitalize" value="0" selected>No</option>
                        <?php else: ?>
                        	<option style="text-transform: capitalize" value="1" selected>Si</option>
                        	<option style="text-transform: capitalize" value="0">No</option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <?php if($menu->submenu==1): ?>
            	<div class="form-group row" id="padres">
            <?php else: ?>
            	<div class="form-group row" id="padres" style="display: none;">
            <?php endif; ?>
                <label for="padre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Padre')); ?></label>

                <div class="col-md-6" style="display: inline-block;">
                    <select class="form-control mb-2" name="padre" id="padre" required style="text-transform: capitalize">
                        <option disabled selected>Seleccione una opción</option>
                        <?php $__currentLoopData = $padres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<?php if($padre->nombre!="Cerrar Sesión"): ?>
                        		<?php if($menu->menu_padre==$padre->id): ?>
                        			<option style="text-transform: capitalize" value="<?php echo e($padre->id); ?>" selected><?php echo e($padre->nombre); ?></option>
                        		<?php else: ?>
                        			<option style="text-transform: capitalize" value="<?php echo e($padre->id); ?>" ><?php echo e($padre->nombre); ?></option>
                        		<?php endif; ?>
                        	<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="fa fa-fw mr-3"><i id="icono" aria-hidden="true" style="display: inline-block;"></i></span>
                </div>
            </div>

            <?php if($menu->submenu==0): ?>
            	<div id="logoMenu">
            	
            <?php else: ?>
            	<div id="logoMenu" style="display: none;">
            <?php endif; ?>
            	<div class="form-group row">
	                <label for="icono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Icono')); ?></label>

	                <div class="col-md-6" style="display: inline-block; width: 100%">
	                    <select class="form-control mb-2" name="iconos" id="iconos" required style="text-transform: capitalize">
	                        <option disabled selected>Seleccione una opción</option>
	                        <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        	<optgroup label="<?php echo e($grupo->nombre); ?>">
	                        		<?php $__currentLoopData = $iconos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        			<?php if($grupo->id==$icono->grupo): ?>
		                        			<?php if($icono->class==$menu->class): ?>
		                        				<option style="text-transform: capitalize" value="<?php echo e($icono->class); ?>" selected><?php echo e($icono->nombre); ?></option>
		                        			<?php else: ?>
		                        				<option style="text-transform: capitalize" value="<?php echo e($icono->class); ?>"><?php echo e($icono->nombre); ?></option>
		                        			<?php endif; ?>
		                        		<?php endif; ?>
	                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        	</optgroup>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </select>
	                </div>
	            </div>

	            <div class="form-group row" style="margin-left: 30%">
	            	<div id="inicial" style="display: block;">
		            	<span>
	            			<i class="<?php echo e($menu->class); ?>" aria-hidden="true"></i>
	            		</span>
	            	</div>
	            	<div id="seleccionado" style="display: none;">
	            		<span>
	            			<i id="icon" aria-hidden="true"></i>
	            		</span>
	            	</div>
	            </div>
        	</div>

        	<div class="form-group row">
                <label for="orden" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Orden')); ?></label>

                <div class="col-md-6">
                    <input id="orden" type="number" class="form-control <?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="orden" required autocomplete="orden" autofocus value="<?php echo e($menu->orden); ?>">

                    <?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Editar')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script src="../../../js/menuPadre.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/administrativo/menu/edit.blade.php ENDPATH**/ ?>
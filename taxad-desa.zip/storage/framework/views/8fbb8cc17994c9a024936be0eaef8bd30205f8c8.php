<title>Taxad | Taxis</title>

<?php $__env->startSection('formulario'); ?>
    <div class="container">
        <form action="<?php echo e(route('tarifa.editar')); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            
            <?php $__currentLoopData = $tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <div class="form-group row">
                    <label for="<?php echo e($tarifa->dia); ?>" class="col-md-4 col-form-label text-md-right"><?php echo e($tarifa->dia); ?></label>

                    <div class="col-md-6">
                        <input id="<?php echo e($tarifa->dia); ?>" type="number" class="form-control" name="<?php echo e($tarifa->dia); ?>" required autofocus value="<?php echo e($tarifa->tarifa); ?>">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Editar')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/tarifas/edit.blade.php ENDPATH**/ ?>
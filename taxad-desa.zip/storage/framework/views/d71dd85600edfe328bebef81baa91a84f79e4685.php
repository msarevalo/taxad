<title>Taxad | Taxis</title>

<?php $__env->startSection('formulario'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" id="success-alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <form action="<?php echo e(route('taxi.asignar', $taxi->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="placa" value="<?php echo e($taxi->placa); ?>" disabled class="form-control mb-2" required>
            <select style="text-transform: capitalize" name="idCond[]" class="form-control mb-2" multiple="multiple" required>
                <option selected disabled>Seleccione una opcion</option>
                <?php $__currentLoopData = $conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option style="text-transform: capitalize" value="<?php echo e($conductor->id); ?>"><?php echo e($conductor->name); ?> <?php echo e($conductor->lastname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-primary btn-block" type="submit">Agregar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/asigna.blade.php ENDPATH**/ ?>
<title>Taxad | Permisos</title>

<?php $__env->startSection('formulario'); ?>

<div class="container">
</div>

<h1>Permisos <?php echo e($nombre->nombrePerfil); ?>:</h1>
<?php echo e($perfil); ?><br><br>

<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre Menú</th>
            <th scope="col">Permisos</th>
        </tr>
    </thead>
    <tbody>
		<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<th>
					<?php echo e($menu->id); ?>

				</th>
				<td>
					<?php echo e($menu->nombre); ?>

				</td>
				<td>
					<select style="text-transform: capitalize" name="<?php echo e($menu->nombre); ?>[]" class="form-control mb-2" multiple="multiple" required>
						<option style="text-transform: capitalize" value="verm-<?php echo e($menu->id); ?>">Ver Menu</option>
		                <option style="text-transform: capitalize" value="ver-<?php echo e($menu->id); ?>">Ver</option>
		                <option style="text-transform: capitalize" value="crear-<?php echo e($menu->id); ?>">Crear</option>
		                <option style="text-transform: capitalize" value="editar-<?php echo e($menu->id); ?>">Editar</option>
		                <option style="text-transform: capitalize" value="eliminar-<?php echo e($menu->id); ?>">Eliminar</option>
		            </select>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/administrativo/permisos/configurar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('formulario'); ?>

<?php dump($w[0] . $w[1] . $w[2] . $w[3] . ' ' . $w[6] . $w[7]); ?>

<input type="date" name="" max="<?php echo e($w); ?>">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/gastos.blade.php ENDPATH**/ ?>
<?php $__env->startSection('formulario'); ?>

<?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('mensaje-delete')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('mensaje-delete')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('documento')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('documento')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <a href="<?php echo e(route('conductor.crea')); ?>" class="btn btn-primary">Crear</a>
    </div>
    <h1>Listado Conductores:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">Categoria</th>
            <th scope="col">Estado</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e(route('categoria.detalle', $categoria)); ?>">
                    <?php echo e($categoria->categoria); ?>

                </a>
            </td>
            <td>
                <?php if($categoria->estado==1): ?>
                    Activo
                <?php else: ?>
                    Inactivo
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(route('conductor.edita', $categoria)); ?>" style="text-decoration: none">
                        <button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                    </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($categorias->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/categorias.blade.php ENDPATH**/ ?>
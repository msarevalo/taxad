<title>Cambio contraseña</title>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Cambio de contraseña')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('cambiar')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="npass" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Nueva Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="npass" type="password" class="form-control<?php echo e($errors->has('npass') ? ' is-invalid' : ''); ?>" name="npass" value="<?php echo e(old('npass')); ?>" required autofocus>

                                <?php if($errors->has('npass')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('npass')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="rpass" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Repitir contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="rpass" type="password" class="form-control <?php $__errorArgs = ['rpass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rpass" required autocomplete="current-password">

                                <?php $__errorArgs = ['rpass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Cambiar')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views//cambio.blade.php ENDPATH**/ ?>
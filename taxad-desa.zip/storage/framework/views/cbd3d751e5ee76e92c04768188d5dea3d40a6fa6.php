<title>Taxad | Login</title>

<?php $__env->startSection('formulario'); ?>
    <h1>Login</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views//login.blade.php ENDPATH**/ ?>
<title>Taxad | Marcas</title>

<?php $__env->startSection('formulario'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <a href="<?php echo e(route('marca.crea')); ?>" class="btn btn-primary">Crear Marca</a>
    </div>
    <h1>Listado de Marcas de Taxis:</h1>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Marca</th>
            <th scope="col">Estado</th>
            <th scope="col">Fecha Creacion</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($marca->id); ?></th>
                <td>
                    <a href="<?php echo e(route('marca.detalle', $marca)); ?>">
                        <?php echo e($marca->marca); ?>

                    </a>
                </td>
                <?php if($marca->estado==1): ?>
                    <td>Activo</td>
                <?php else: ?>
                    <td>Inactivo</td>
                <?php endif; ?>
                <td><?php echo e($marca->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('marca.edita', $marca)); ?>">
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($marcas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/marcas.blade.php ENDPATH**/ ?>
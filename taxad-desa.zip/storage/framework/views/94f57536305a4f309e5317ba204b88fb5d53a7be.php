<title>Taxad | Conductor</title>

<?php $__env->startSection('formulario'); ?>
    <h1>Detalle del conductor <?php echo e($conductor->name); ?>:</h1>
    <h4>id: <?php echo e($conductor->id); ?></h4>
    <h4>Documento: <?php echo e($conductor->document); ?></h4>
    <h4>Nombres: <?php echo e($conductor->name); ?></h4>
    <h4>Apellidos: <?php echo e($conductor->lastname); ?></h4>
    <?php if($conductor->estado): ?>
        <h4>Estado: Activo</h4>
    <?php else: ?>
        <h4>Estado: Inactivo</h4>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/conductores/detalle.blade.php ENDPATH**/ ?>
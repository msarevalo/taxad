<title>Taxad | Menus</title>

<?php $__env->startSection('formulario'); ?>

<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('negar')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('negar')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<div class="container">
    </div>
    <h1>Listado Menus:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Ruta</th>
            <th scope="col">Submenu</th>
            <th scope="col">Menu Padre</th>
            <th scope="col">Logo</th>
            <th scope="col">Orden</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($menu->id); ?></th>
            <td>
                <a href="#">
                    <?php echo e($menu->nombre); ?>

                </a>
            </td>
            <td>
                <?php if($menu->ruta==NULL): ?>
                   	Menú Padre
                <?php elseif($menu->nombre=="Cerrar Sesión"): ?>
                	Cerrar Sesión
                <?php else: ?>
                  	<a href="<?php echo e($menu->ruta); ?>">
                  		<?php echo e($menu->ruta); ?>

                   	</a>
                <?php endif; ?>
            </td>
            <td>
                <?php if($menu->submenu==0): ?>
                	No
                <?php else: ?>
                	Si
                <?php endif; ?>
            </td>
            <td>
            	<?php if($menu->submenu==1): ?>
	                <?php $__currentLoopData = $padres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <?php if($padre->id==$menu->menu_padre): ?>
	                        <?php echo e($padre->nombre); ?>

	                    <?php endif; ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                	-
                <?php endif; ?>
            </td>
            <td>
            	<span class="fa fa-fw mr-3"><i class="<?php echo e($menu->class); ?>" aria-hidden="true"></i></span>
            </td>
            <td><?php echo e($menu->orden); ?></td>
            <td>
            	<?php if($menu->nombre=="Perfil"): ?>
            	<?php elseif($menu->nombre=="Menús"): ?>
            	<?php elseif($menu->nombre=="Cerrar Sesión"): ?>
            	<?php else: ?>
            	<a href="<?php echo e(route('menu.edita', $menu->id)); ?>" style="text-decoration: none">
                	<button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                 </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($menus->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/menus.blade.php ENDPATH**/ ?>
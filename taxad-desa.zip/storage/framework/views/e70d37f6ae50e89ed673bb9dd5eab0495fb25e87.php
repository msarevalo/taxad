<title>Taxad | Permisos</title>

<?php $__env->startSection('formulario'); ?>

<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('negar')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('negar')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<div class="container">
    </div>
    <h1>Permisos:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre Perfil</th>
            <th scope="col">Menus Activos</th>
            <th scope="col">Menus Asignados</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $listap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<tr>
	        		<th>
	        			<?php echo e($perfil->id); ?>

	        		</th>
	        		<td>
	        			<?php echo e($perfil->nombrePerfil); ?>

	        		</td>
	        		<td>
	        			<?php echo e($menus); ?>

	        		</td>
	        		<td>
	        			<?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        				<?php if($permiso->perfil==$perfil->id): ?>
	        					<?php echo e($permiso->conteo); ?>

	        				<?php endif; ?>
	        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        		</td>
	        		<td>
	        			<?php if($perfil->nombrePerfil!=="Superadmin"): ?>
		        			<a href="<?php echo e(route('permisos.configura', $perfil->id)); ?>" style="text-decoration: none">
	                			<button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-cog" aria-hidden="true" title="Configurar Permisos"></i></button>
	                 		</a>
	                 	<?php endif; ?>
	        		</td>
        		</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/permisos.blade.php ENDPATH**/ ?>
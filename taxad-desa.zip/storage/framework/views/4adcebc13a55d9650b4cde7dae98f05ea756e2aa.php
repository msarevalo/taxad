<?php $__env->startSection('formulario'); ?>

<a class="btn btn-light"  href="#">Atras</a>
    <a class="btn btn-info"  href="#">Editar</a>
    <a class="btn btn-primary"  href="#">Reportar</a>
    <h3>Descripciones de la categoria <?php echo e($categoria->categoria); ?>:</h3>
    <table class="table col-8">
      <thead>
        <tr>
       		<th scope="col">Descripcion</th>
        	<th scope="col">Estado</th>
        	<th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
      	<?php $__currentLoopData = $descripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $descripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      		<tr>
      			<td>
      				<?php echo e($descripcion->descripcion); ?>

      			</td>
      			<td>
      				<?php if($descripcion->estado==1): ?>
      					Activo
      				<?php else: ?>
      					Inactivo
      				<?php endif; ?>
      			</td>
      			<td>
      				<a href="#" style="text-decoration: none">
                        <button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                    </a>
      			</td>
      		</tr>
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/categorias/detalle.blade.php ENDPATH**/ ?>
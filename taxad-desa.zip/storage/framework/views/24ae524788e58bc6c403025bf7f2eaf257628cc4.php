<title>Taxad | Taxis</title>

<?php $__env->startSection('formulario'); ?>
    <div class="container">
        <form action="<?php echo e(route('taxi.editar', $taxi->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="placa" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Placa')); ?></label>

                <div class="col-md-6">
                    <input id="placa" type="text" class="form-control <?php $__errorArgs = ['placa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="placa" required autocomplete="placa" autofocus value="<?php echo e($taxi->placa); ?>" disabled>

                    <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="marca" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Marca')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="marca" required style="text-transform: capitalize">
                        <option selected disabled>Seleccione una marca</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($marca->id==$taxi->marca): ?>
                                <option style="text-transform: capitalize" value="<?php echo e($marca->id); ?>" selected><?php echo e($marca->marca); ?></option>
                            <?php else: ?>
                                <option style="text-transform: capitalize" value="<?php echo e($marca->id); ?>"><?php echo e($marca->marca); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group row">
                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Conductores')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="idCond[]" required style="text-transform: capitalize" multiple="multiple">
                        <option selected disabled>Seleccione un conductor</option>
                        <?php $__currentLoopData = $conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($usuario=""); ?>
                            <?php $__currentLoopData = $asignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($conductor->id===$asigna->idCond): ?>
                                    <option selected style="text-transform: capitalize" value="<?php echo e($conductor->id); ?>"><?php echo e($conductor->name); ?> <?php echo e($conductor->lastname); ?></option>
                                    <?php ($usuario=$conductor->id); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($conductor->id!==$usuario): ?>
                                <option style="text-transform: capitalize" value="<?php echo e($conductor->id); ?>"><?php echo e($conductor->name); ?> <?php echo e($conductor->lastname); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group row">
                <label for="modelo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Modelo')); ?></label>

                <div class="col-md-6">
                    <input id="modelo" type="text" class="form-control <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="modelo" value="<?php echo e($taxi->modelo); ?>" required autocomplete="modelo" autofocus>

                    <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="serie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Serie')); ?></label>

                <div class="col-md-6">
                    <input id="serie" type="number" class="form-control <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="serie" value="<?php echo e($taxi->serie); ?>" required autocomplete="serie" autofocus min="2000" name="serie">

                    <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="form-group row">
                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="estado" required>
                    <?php if($taxi->estado==1): ?>
                        <option selected value="1">Activo</option>
                        <option value="0">Inactivo</option>
                    <?php else: ?>
                        <option value="1">Activo</option>
                        <option value="0" selected>Inactivo</option>
                    <?php endif; ?>
                    </select>
                </div>
            </div>

            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Editar')); ?>

                    </button>
                </div>
            </div>
        </form>

        <table class="table">
            <tr>
                <td>
                    <?php if($soat==null): ?>
                        <label for="name" class="col-6"><?php echo e(__('No has cargado aun el SOAT para este vehiculo')); ?></label>
                    <?php else: ?>
                        <label for="name" class="col-3"><?php echo e(__('SOAT')); ?></label>
                        <a href="../../documentos/soat/<?php echo e($soat->documento); ?>" class="col-6" style="text-decoration: none;" target="_blank">
                            <img src="../../img/pdf.png" style="width: 3.5%"> <?php echo e($soat->documento); ?>

                        </a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php if($tp==null): ?>
                        <label for="name" class="col-6"><?php echo e(__('No has cargado aun el TP para este vehiculo')); ?></label>
                    <?php else: ?>
                        <label for="name" class="col-3"><?php echo e(__('Tarjeta de Propiedad')); ?></label>
                        <a href="../../documentos/tp/<?php echo e($tp->documento); ?>" class="col-6" style="text-decoration: none;" target="_blank">
                            <img src="../../img/pdf.png" style="width: 5%"> <?php echo e($tp->documento); ?>

                        </a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php if($tarjeton==null): ?>
                        <label for="name" class="col-6"><?php echo e(__('No has cargado aun el Tarjeton para este vehiculo')); ?></label>
                    <?php else: ?>
                        <label for="name" class="col-3"><?php echo e(__('Tarjeton')); ?></label>
                        <a href="../../documentos/tarjeton/<?php echo e($tarjeton->documento); ?>" class="col-6" style="text-decoration: none;" target="_blank">
                            <img src="../../img/pdf.png" style="width: 5%"> <?php echo e($tarjeton->documento); ?>

                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <a href="<?php echo e(route('taxi.soat', $taxi->id)); ?>" class="btn btn-primary btn-block">Cargar/Actualizar Documentos</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/edita.blade.php ENDPATH**/ ?>
<title>Taxad | Taxi</title>

<?php $__env->startSection('formulario'); ?>
    <h1>Detalle de la Marca <?php echo e($marca->marca); ?>:</h1>
    <h4>id: <?php echo e($marca->id); ?></h4>
    <h4>Marca: <?php echo e($marca->marca); ?></h4>
    <?php if($marca->estado): ?>
        <h4>Estado: Activo</h4>
    <?php else: ?>
        <h4>Estado: Inactivo</h4>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/marcas/detalle.blade.php ENDPATH**/ ?>
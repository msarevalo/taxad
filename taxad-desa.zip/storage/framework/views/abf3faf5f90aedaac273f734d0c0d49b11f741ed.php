<title>Taxad | Menus</title>

<?php $__env->startSection('formulario'); ?>

<div class="container">
    </div>
    <h1>Listado Perfiles:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Estado</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<tr>
        		<th>
        			<?php echo e($perfil->id); ?>

        		</th>
        		<td>
        			<?php echo e($perfil->nombrePerfil); ?>

        		</td>
                <td>
                    <?php if($perfil->estado==1): ?>
                        Activo
                    <?php else: ?>
                        Inactivo
                    <?php endif; ?>
                </td>
        		<td>
        			<?php if($perfil->nombrePerfil!="Superadmin"): ?>
                        <a href="<?php echo e(route('perfil.edita', $perfil->id)); ?>" style="text-decoration: none">
                    		<button style="width: 30px; height: 30px" class="btn btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                     	</a>
                    <?php endif; ?>
        		</td>
        	</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/perfiles.blade.php ENDPATH**/ ?>
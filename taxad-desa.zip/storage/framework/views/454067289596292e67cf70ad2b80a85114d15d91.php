<title>Taxad | Taxis</title>

<?php $__env->startSection('formulario'); ?>
	<?php if(session('sinMarca')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('sinMarca')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <form action="<?php echo e(route('separador.crear')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Texto Separador')); ?></label>

                <div class="col-md-6">
                    <input id="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autocomplete="nombre" autofocus>

                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

             <div class="form-group row">
                <label for="menu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Menu Posterior')); ?></label>

                <div class="col-md-6">
                    <select class="form-control mb-2" name="menu" id="menu" required style="text-transform: capitalize">
                        <option disabled selected>Seleccione una opción</option>
                        <?php $__currentLoopData = $padres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($padre->nombre!="Cerrar Sesión"): ?>
                                <option style="text-transform: capitalize" value="<?php echo e($padre->id); ?>" ><?php echo e($padre->nombre); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="fa fa-fw mr-3"><i id="icono" aria-hidden="true" style="display: inline-block;"></i></span>
                </div>
            </div>


            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Agregar')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/administrativo/separador/create.blade.php ENDPATH**/ ?>
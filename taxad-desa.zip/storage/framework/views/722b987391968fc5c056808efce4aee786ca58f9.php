<title>Taxad | Tarifas</title>

<?php $__env->startSection('formulario'); ?>
    
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="container">
        <a href="<?php echo e(route('tarifa.edita')); ?>" class="btn btn-primary">Actualizar Tarifas</a>
    </div>
    <h1>Tarifas:</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Día</th>
            <th scope="col">Tarifa</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($tarifa->id); ?>

            </td>
            <td>
                <?php echo e($tarifa->dia); ?>

            </td>
            <td>
                <?php echo e($tarifa->tarifa); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/tarifas.blade.php ENDPATH**/ ?>
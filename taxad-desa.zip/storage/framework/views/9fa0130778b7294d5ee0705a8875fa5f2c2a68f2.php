<?php $__env->startSection('formulario'); ?>

<?php ($semana = date('W')); ?>
<?php ($semana = $semana-1); ?>
<?php ($año = date('Y')); ?>

<?php if($semana<=9): ?>
<?php ($maximo= $año . '-W0' . $semana); ?>
<?php else: ?>
<?php ($maximo=$año . '-W' . $semana); ?>
<?php endif; ?>
<?php ($dia=date("Y-m-d")); ?>
<div style="height:30px"></div>
<form action="<?php echo e(route('taxi.reportar', $taxi->id)); ?>" method="post">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>


	<div class="form-group row">
		<label for="placa" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Placa')); ?></label>
		<div class="col-md-3">
			<input id="placa" type="text" class="form-control <?php $__errorArgs = ['placa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="placa" value="<?php echo e($taxi->placa); ?>" disabled>

			<?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group row">
		<label for="fecha" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha Actual')); ?></label>
		<div class="col-md-3">
			<input id="fecha" type="date" class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fecha" value="<?php echo e($dia); ?>" disabled>

			<?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group row">
		<label for="semana" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Semana')); ?></label>

		<div class="col-md-3">
			<input id="semana" type="week" class="form-control <?php $__errorArgs = ['semana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="semana" value="<?php echo e(old('semana')); ?>" max="<?php echo e($maximo); ?>" required autocomplete="semana" autofocus>

			<?php $__errorArgs = ['semana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="col-md-3" style="margin-left: 15%">
		<table class="table col-md-3">
			<thead class="thead-light">
				<tr>
					<th colspan="8" style="text-align: center;">
						Pico y Placa
					</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>
						Domingo
					</td>
					<td>
						<p style="cursor: pointer;" id="lunes">Lunes</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="martes">Martes</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="miercoles">Miercoles</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="jueves">Jueves</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="viernes">Viernes</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="sabado">Sabado</p>
					</td>
					<td>
						<p style="cursor: pointer;" id="sinpp">No Hay</p>
					</td>
				</tr>
				<tr style="text-align: center;">
					<td>
						N/A
					</td>
					<td>
						<input id="ppL" type="radio" name="ppL" value="<?php echo e(old('ppL')); ?>" autocomplete="ppL" autofocus title="Pico y Placa" required>
					</td>
					<td>
						<input id="ppM" type="radio" name="ppM" value="<?php echo e(old('ppM')); ?>" autocomplete="ppM" autofocus title="Pico y Placa">
					</td>
					<td>
						<input id="ppMi" type="radio" name="ppMi" value="<?php echo e(old('ppMi')); ?>" autocomplete="ppMi" autofocus title="Pico y Placa">
					</td>
					<td>
						<input id="ppJ" type="radio" name="ppJ" value="<?php echo e(old('ppJ')); ?>" autocomplete="ppJ" autofocus title="Pico y Placa">
					</td>
					<td>
						<input id="ppV" type="radio" name="ppV" value="<?php echo e(old('ppV')); ?>" autocomplete="ppV" autofocus title="Pico y Placa">
					</td>
					<td>
						<input id="ppS" type="radio" name="ppS" value="<?php echo e(old('ppS')); ?>" autocomplete="ppS" autofocus title="Pico y Placa">
					</td>
					<td>
						<input id="spp" type="radio" name="spp" value="<?php echo e(old('spp')); ?>" autocomplete="spp" autofocus title="Sin Pico y Placa">
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<table class="table col-16">
		<tbody>
			<tr>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Domingo
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="">
													<label for="producidoD" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoD" type="number" class="form-control <?php $__errorArgs = ['producidoD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoD" value="<?php echo e($tarifas[6]->tarifa); ?>" required autocomplete="producidoD" autofocus required>

													<?php $__errorArgs = ['producidoD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosD" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="gastosD" type="number" class="form-control <?php $__errorArgs = ['gastosD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosD" value="0" required autocomplete="gastosD" autofocus>

													<?php $__errorArgs = ['gastos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>

											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosD" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosD" type="number" class="form-control <?php $__errorArgs = ['otrosD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosD" value="0" required autocomplete="otrosD" autofocus>

													<?php $__errorArgs = ['otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalD" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalD" type="number" class="form-control <?php $__errorArgs = ['totalD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="total" value="0" autocomplete="totalD" autofocus disabled>

													<?php $__errorArgs = ['totalD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Lunes
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="form-group row">
													<label for="producidoL" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoL" type="number" class="form-control <?php $__errorArgs = ['producidoL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoL" value="<?php echo e($tarifas[0]->tarifa); ?>" required autocomplete="producidoL" autofocus>

													<?php $__errorArgs = ['producidoL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosL" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="gastosL" type="number" class="form-control <?php $__errorArgs = ['gastosL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosL" value="0" required autocomplete="gastosL" autofocus>

													<?php $__errorArgs = ['gastosL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosL" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosL" type="number" class="form-control <?php $__errorArgs = ['otrosL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosL" value="0" required autocomplete="otrosL" autofocus>

													<?php $__errorArgs = ['otrosL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalL" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalL" type="number" class="form-control <?php $__errorArgs = ['totalL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalL" value="0" autocomplete="totalL" autofocus disabled>

													<?php $__errorArgs = ['totalL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
			</tr>
			<tr>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Martes
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="form-group row">
													<label for="producidoM" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoM" type="number" class="form-control <?php $__errorArgs = ['producidoM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoM" value="<?php echo e($tarifas[1]->tarifa); ?>" required autocomplete="producidoM" autofocus>

													<?php $__errorArgs = ['producidoM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosM" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="gastosM" type="number" class="form-control <?php $__errorArgs = ['gastosM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosM" value="0" required autocomplete="gastosM" autofocus>

													<?php $__errorArgs = ['gastosM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosM" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosM" type="number" class="form-control <?php $__errorArgs = ['otrosM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosM" value="0" required autocomplete="otrosM" autofocus>

													<?php $__errorArgs = ['otrosM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalM" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalM" type="number" class="form-control <?php $__errorArgs = ['totalM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalM" value="0" autocomplete="totalM" autofocus disabled>

													<?php $__errorArgs = ['totalM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Miercoles
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="form-group row">
													<label for="producidoMi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoMi" type="number" class="form-control <?php $__errorArgs = ['producidoMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoMi" value="<?php echo e($tarifas[2]->tarifa); ?>" required autocomplete="producidoMi" autofocus>

													<?php $__errorArgs = ['producidoMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosMi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="gastosMi" type="number" class="form-control <?php $__errorArgs = ['gastosMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosMi" value="0" required autocomplete="gastosMi" autofocus>

													<?php $__errorArgs = ['gastosMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosMi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosMi" type="number" class="form-control <?php $__errorArgs = ['otrosMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosMi" value="0" required autocomplete="otrosMi" autofocus>

													<?php $__errorArgs = ['otrosMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalMiMi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalMi" type="number" class="form-control <?php $__errorArgs = ['totalMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalMi" value="0" autocomplete="totalMi" autofocus disabled>

													<?php $__errorArgs = ['totalMi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
			</tr>
			<tr>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Jueves
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="form-group row">
													<label for="producidoJ" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoJ" type="number" class="form-control <?php $__errorArgs = ['producidoJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoJ" value="<?php echo e($tarifas[3]->tarifa); ?>" required autocomplete="producidoJ" autofocus>

													<?php $__errorArgs = ['producidoJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosJ" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="gastosJ" type="number" class="form-control <?php $__errorArgs = ['gastosJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosJ" value="0" required autocomplete="gastosJ" autofocus>

													<?php $__errorArgs = ['gastosJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosJ" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosJ" type="number" class="form-control <?php $__errorArgs = ['otrosJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosJ" value="0" required autocomplete="otrosJ" autofocus>

													<?php $__errorArgs = ['otrosJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalJ" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalJ" type="number" class="form-control <?php $__errorArgs = ['totalJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalJ" value="0" autocomplete="totalJ" autofocus disabled>

													<?php $__errorArgs = ['totalJ'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Viernes
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<td>
												<div class="form-group row">
													<label for="producidoV" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</td>
											<td>
												<div class="col-md-12">
													<input id="producidoV" type="number" class="form-control <?php $__errorArgs = ['producidoV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoV" value="<?php echo e($tarifas[4]->tarifa); ?>" required autocomplete="producidoV" autofocus>

													<?php $__errorArgs = ['producidoV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="gastosV" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="gastosV" type="number" class="form-control <?php $__errorArgs = ['gastosV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosV" value="0" required autocomplete="gastosV" autofocus>

													<?php $__errorArgs = ['gastosV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="otrosV" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="otrosV" type="number" class="form-control <?php $__errorArgs = ['otrosV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosV" value="0" required autocomplete="otrosV" autofocus>

													<?php $__errorArgs = ['otrosV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="form-group row">
													<label for="totalV" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</td>
											<td colspan="2">
												<div class="col-md-12">
													<input id="totalV" type="number" class="form-control <?php $__errorArgs = ['totalV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalV" value="0" autocomplete="totalV" autofocus disabled>

													<?php $__errorArgs = ['totalV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
			</tr>
			<tr>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-light" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												Sabado
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>
										<tr>
											<th>
												<div class="form-group row">
													<label for="producidoS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producido')); ?></label>
												</div>
											</th>
											<th>
												<div class="col-md-12">
													<input id="producidoS" type="number" class="form-control <?php $__errorArgs = ['producidoS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoS" value="<?php echo e($tarifas[5]->tarifa); ?>" required autocomplete="producidoS" autofocus>

													<?php $__errorArgs = ['producidoS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</th>
										</tr>
										<tr>
											<th>
												<div class="form-group row">
													<label for="gastosS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
												</div>
											</th>
											<th colspan="2">
												<div class="col-md-12">
													<input id="gastosS" type="number" class="form-control <?php $__errorArgs = ['gastosS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosS" value="0" required autocomplete="gastosS" autofocus>

													<?php $__errorArgs = ['gastos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</th>
										</tr>
										<tr>
											<th>
												<div class="form-group row">
													<label for="otrosS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Otros')); ?></label>
												</div>
											</th>
											<th colspan="2">
												<div class="col-md-12">
													<input id="otrosS" type="number" class="form-control <?php $__errorArgs = ['otrosS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otrosS" value="0" required autocomplete="otrosS" autofocus>

													<?php $__errorArgs = ['otrosS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</th>
										</tr>
										<tr>
											<th>
												<div class="form-group row">
													<label for="totalS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total')); ?></label>
												</div>
											</th>
											<th colspan="2">
												<div class="col-md-12">
													<input id="totalS" type="number" class="form-control <?php $__errorArgs = ['totalS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="totalS" value="0" autocomplete="totalS" autofocus disabled>

													<?php $__errorArgs = ['totalS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</th>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</th>
				<th>
					<div class="showcase--wrapper">
						<div class="accordion-wrapper">
							<div class="accordion-tab"> 
								<table class="table col-3" style="width: 350px">
									<thead class="thead-dark" style="cursor: pointer;">
										<tr>
											<th colspan="3" style="text-align: center;">
												TOTAL SEMANA
											</th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="accordion-panel tab-collapsed">
								<div class="accordion-panel-content">
									<table>

										<tbody>
											<tr>
												<th>
													<div class="">
														<label for="producidoSem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Producidos')); ?></label>
													</div>
												</th>
												<th>
													<div class="col-md-12">
														<input id="producidoSem" type="number" class="form-control <?php $__errorArgs = ['producidoSem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producidoSem" value="<?php echo e($tarifas[0]->tarifa+$tarifas[1]->tarifa+$tarifas[2]->tarifa+$tarifas[3]->tarifa+$tarifas[4]->tarifa+$tarifas[5]->tarifa+$tarifas[6]->tarifa); ?>" required autocomplete="producidoSem" autofocus disabled>

														<?php $__errorArgs = ['producidoSem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>

												</th>
											</tr>

											<tr>
												<th>
													<div class="">
														<label for="gastosSem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gastos')); ?></label>
													</div>
												</th>
												<th>
													<div class="col-md-12">
														<input id="gastosSem" type="number" class="form-control <?php $__errorArgs = ['gastosSem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gastosSem" value="0" required autocomplete="gastosSem" autofocus disabled>
														<?php $__errorArgs = ['gastosSem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>	
												</th>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					<table>
						<thead><tr><td colspan="3" style="text-align: center;">TOTAL A PAGAR</td></tr></thead>
						<tbody>
							<tr>
								<th>
									<div class="">
										<label for="pagar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pago')); ?></label>
									</div>
								</th>
								<th>
									<div class="col-md-12">
										<input id="pagar" type="number" class="form-control <?php $__errorArgs = ['pagar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pagar" value="<?php echo e($tarifas[0]->tarifa+$tarifas[1]->tarifa+$tarifas[2]->tarifa+$tarifas[3]->tarifa+$tarifas[4]->tarifa+$tarifas[5]->tarifa+$tarifas[6]->tarifa); ?>" required autocomplete="pagar" autofocus disabled>

										<?php $__errorArgs = ['pagar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
								</th>
							</tr>
						</tbody>
					</table>
					<div class="form-group row mb-0">
						<div class="col-md-6 offset-md-4">
							<button type="submit" class="btn btn-primary">
								<?php echo e(__('Registrar')); ?>

							</button>
						</div>
					</div>
				</th>
			</tr>
		</tbody>
	</table>
</form>

<style type="text/css">
	// Shades
	$c-grey--lightest: #f2f2f2;
	$c-grey--lighter: #ebebeb;
	$c-grey--light: #e8e7e6;
	$c-grey: #cccbca;
	$c-grey--darker: #adadac;
	$c-grey--darkest: #575756;
	$c-grey-slate: #708090;



	.accordion-wrapper {
		border-top: 1px solid $c-grey--lightest;
		box-shadow: 0px 1px 0px $c-grey--lightest;
		background: white;
	}


	.accordion-tab {
		padding: 1px 18px;
		background: transparent;
		transition: 0.4s;
		position: relative;
		padding-right: 86px;


		&:hover {
			cursor: pointer;
		}

		&::before {
			content:'';
			height: 4px;
			width: 28px;
			background-color: $c-grey--darker;
			position: absolute;
			right: 40px;
			top: 32px;
			transition: 0.4s;
		}

		&::after {
			content:'';
			height: 4px;
			width: 28px;
			background-color: $c-grey--darker;
			position: absolute;
			right: 40px;
			top: 32px;
			transform: rotate(-90deg);
			transition: 0.4s;
		}
	}

	.accordion-tab.tab-active {
		background: $c-grey--lightest;
		transition: 0.2s;
		box-shadow: inset 0px 2px 3px $c-grey--lighter;

		&::after {
			transform: rotate(0deg);
			transition: 0.2s;
		}
	}



	.accordion-panel {
		display: block;
		transition: 0.4s;
		max-height: none;
		overflow: hidden;
		background: $c-grey--lightest;
	}

	.accordion-panel.tab-collapsed {
		max-height: 0;
		transition: 0.2s;

		.accordion-panel-content {
			transform: translateY(-100px);
			transition: 0.2s;
		}
	}

	.accordion-panel-content {
		padding: 6px 18px 18px;
		transition: 0.2s ease;
		transform: translateY(0);
		transform-origin: 50% 0;
	}

	.showcase--wrapper {
		max-width: 800px;
		margin: 0 auto;
	}

</style>

<script type="text/javascript">
	function accordionToggle() {
		var accordion = document.getElementsByClassName('accordion-wrapper');

		for (i = 0; i < accordion.length; i++) {
			var tab = accordion[i].querySelector('.accordion-tab');

			tab.addEventListener('click', function() {
				this.classList.toggle("tab-active");
				var panel = this.nextElementSibling;
				panel.classList.toggle("tab-collapsed");
			});   
		}  
	}

	accordionToggle();
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/reporta.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/taxis/reportar.blade.php ENDPATH**/ ?>
<title>Taxad | Calendario</title>

<?php $__env->startSection('formulario'); ?>
<html>
  <head>
    <title></title>
    <meta content="">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Exo&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
    body{
      font-family: 'Exo', sans-serif;
    }
    .header-col{
      background: #E3E9E5;
      color:#536170;
      text-align: center;
      font-size: 20px;
      font-weight: bold;
    }
    .header-calendar{
      background: #EE192D;color:white;
    }
    .box-day{
      border:1px solid #E3E9E5;
      height:150px;
    }
    .box-dayoff{
      border:1px solid #E3E9E5;
      height:150px;
      background-color: #ccd1ce;
    }
    .right{
      float: right;
    }
    </style>

  </head>
  <body>

    <div class="container">
      <div style="height:50px"></div>
      <a class="btn btn-light"  href="<?php echo e(asset('/calendario')); ?>">Atras</a>
      <?php ($timezone  = -5); ?>
            <?php ($fecha=gmdate("Y-m-d", time() + 3600*($timezone+date("I")))); ?>
      <?php if(Auth::user()->id==$event->propietario && $event->fecha>=$fecha && $event->estado==1): ?>
        <div class="right">
          <a href="<?php echo e(route('calendario.edita', $event->id)); ?>" style="text-decoration: none;" class="btn btn-info">Editar</a>
          <a href="<?php echo e(route('calendario.delete', $event->id)); ?>" style="text-decoration: none;" class="btn btn-danger">Eliminar</a>
        </div>
      <?php endif; ?>
      <h1 style="margin-top: 20px;"><?php echo e($event->titulo); ?></h1>
      <?php if($event->broadcast==0): ?>
        <p style="font-size: 14.5px;">Evento propio</p>
      <?php else: ?>
        <p style="font-size: 14.5px;">Evento de la comunidad</p>
      <?php endif; ?>
      <hr>

      <div class="col-md-6">
        <div class="fomr-group">
            <h5 style="display: inline;">Prioridad:&nbsp;&nbsp;&nbsp;&nbsp; </h5>
            <?php if($event->prioridad==1): ?>
              Alto
            <?php elseif($event->prioridad==2): ?>
              Medio
            <?php else: ?>
              Bajo
            <?php endif; ?>
          </div><br><br>
          <div class="fomr-group">
            <h5>Descripcion del Evento</h5>
            <?php echo e($event->descripcion); ?>

          </div><br><br>
          
          <div class="fomr-group">
            <h5 style="display: inline;">Fecha: &nbsp;&nbsp;&nbsp;&nbsp;</h5>
            <?php echo e($event->fecha[8]); ?><?php echo e($event->fecha[9]); ?><?php echo e($event->fecha[7]); ?><?php echo e($event->fecha[5]); ?><?php echo e($event->fecha[6]); ?><?php echo e($event->fecha[4]); ?><?php echo e($event->fecha[0]); ?><?php echo e($event->fecha[1]); ?><?php echo e($event->fecha[2]); ?><?php echo e($event->fecha[3]); ?>

          </div>
          <br>
      </div>


      <!-- inicio de semana -->


    </div> <!-- /container -->


  </body>
</html>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="../../js/notificacion.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('autenticacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\taxad\resources\views/evento/evento.blade.php ENDPATH**/ ?>